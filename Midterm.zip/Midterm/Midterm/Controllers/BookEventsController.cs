﻿using Midterm.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Midterm.Controllers
{
    public class BookEventsController : Controller
    {
        public static List<Customer> listCustomer = new List<Customer>();
        // GET: BookEvents
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(Customer customer)
        {
            if (ModelState.IsValid)
            {
                customer.customerIdentification = customer.firstName + " " + customer.lastName + " " + customer.email + " Catering Package" + customer.cateringPackage + " Entertainment Package" + customer.entertainmentPackage;
                listCustomer.Add(customer);
                if(customer.email != customer.confirmEmail)
                {
                    return View("badEmail");
                }
                return View("Confirmation", customer);
            }
            else
            {
                //Validation Error
                return View();
            }

        }


        public ActionResult DisplayCustomer()
        {
            ViewBag.listCustomer = listCustomer;
            return View();
        }

        public ActionResult ClearCustomer()
        {
            listCustomer.Clear();
            return View("DisplayCustomer");
        }

        
    }
}