﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Midterm.Controllers
{
    public class EntertainmentController : Controller
    {
        // GET: Entertainment
        public ActionResult Index()
        {
            return View();
        }
    }
}