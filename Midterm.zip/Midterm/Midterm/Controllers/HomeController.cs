﻿//This is Drexler Tanner's Midterm
//10-27-2018

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Midterm.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult BookEvent()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ViewResult Catering()
        {
            return View();
        }

        public ViewResult EntertainmentView()
        {
            return View();
        }

    }
}