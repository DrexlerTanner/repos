﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Midterm.Models
{
    public class Customer
    {
        public string customerIdentification { get; set; }

        [Required(ErrorMessage = "Please enter your first name")]
        public string firstName { get; set; }

        [Required(ErrorMessage = "Please enter your last name")]
        public string lastName { get; set; }

        [Required(ErrorMessage = "Please enter your email")]
        public string email { get; set; }

        [Required(ErrorMessage = "Please confirm your email")]
        public string confirmEmail { get; set; }

        [Required(ErrorMessage = "Please choose catering package")]
        public string cateringPackage { get; set; }

        [Required(ErrorMessage = "Please choose your entertainment package")]
        public string entertainmentPackage { get; set; }
    }
}